#!/usr/bin/env bash

##########################################################
# Print out the usage of this script, ans then exit
# Globals:
#   none
# Arguments:
#   none
# Outputs:
#   STDOUT the usage
##########################################################
usage() {
    echo 'usage: ./compare.sh [OPTION] <PATH A> <PATH B>'
    echo 'options:'
    echo '-a: compare hidden files instead of ignoring them'
    echo '-h: output information about compare.sh'
    echo '-l: treat symlinks as files instead of ignoring them'
    echo '-n <EXP>: compare only files whose paths follow the REGEX <EXP>'
    echo '-r: compare directories recursively'
    exit 1
}


max() {
    echo "$(( $1 > $2 ? $1 : $2))"
}


##########################################################
# By the option -l, output the types of file that need to find
# Globals:
#   option_l
# Arguments:
#   none
# Outputs:
#   STDOUT the file required types
##########################################################
get_link_option() {
    if ! $option_l ; then
        echo "f,d"
    else
        echo "f,d,l"
    fi
    return 0
}


##########################################################
# According to the option  
# Globals:
#   option_a 
#   option_l
#   EXP
# Arguments:
#   path: the relative path from the compare.sh
# Outputs:
#   STDOUT: the string of files that meet the criteria(format: "<FILE_A> <FILE_B> ...",
#   arrenged lexographically)
##########################################################
get_files_list() {
    local directory_path=
    local link_option=
    local files=
    directory_path="$1"

    # get required file types
    link_option="$(get_link_option)"

    # find directories meet the option_a, and files whose name match REG
    if $option_a; then        
        files=$(find "$directory_path" -maxdepth 1 -type "${link_option}" -a \( -type d -o -regex ".*/.*${EXP}[^/]*" \) | sed -e "s#${directory_path}##g" | \
               LC_ALL=C sort)
    else 
        files=$(find "$directory_path" -maxdepth 1 -type "${link_option}" -not -wholename "${directory_path}.*" -a \( -type d -o -regex ".*/.*${EXP}[^/]*" \) |\
              sed -e "s#${directory_path}##g" | LC_ALL=C sort)
    fi
    echo "$files"
}


##########################################################
# If the input file is a directory, print out the valid files in 
# this directory recursively, or print out the input path directory
# Globals:
#   path_b
#   option_a
# Arguments:
#   file_path, the path need to be created
# Outputs:
#   STDOUT created files
##########################################################
create() {
    local file_path="$1"

    # if the path is not a directory or it's symbol link file, output it directedly
    if [[ ! -d "${path_b}/${file_path}" ]] || [[ -L "${path_b}/${file_path}" ]]; then
        echo "create ${file_path}"
        return 0
    fi


    local files=
    files="$(get_files_list "${path_b}/${file_path}"/ )"
    files=( $files )

    # iterate the files
    local i=0
    for ((; i < ${#files[@]}; i++)); do
        create "${file_path}/${files[i]}"
    done
    return 0
}


##########################################################
# If the input file is a directory, print out the valid files in 
# this directory recursively, or print out the input path directory
# Globals:
#   path_a
#   option_a
# Arguments:
#   file_path, the path need to be deleted
# Outputs:
#   STDOUT deleted files
##########################################################
delete() {
    local file_path="$1"
    if [[ ! -d "${path_a}/${file_path}" ]] || [[ -L "${path_b}/${file_path}" ]]; then
        echo "delete ${file_path}"
        return 0
    fi
    local files=
    files="$(get_files_list "$path_a"/"$file_path_a"/ )"

    files=( $files )
    local i=0
    for ((; i < ${#files[@]}; i++)); do
        delete "${file_path}/${files[i]}"
    done
    
    return 0
}


##########################################################
# Check and compare two non-directory files 
# Globals:
#   path_a
#   path_b
# Arguments:
#   file_path_a, one of the compared files under path_a (omitted path_a/)
#   file_path_b, one of the compared files under path_b (omitted path_b/)
# Outputs:
#   STDOUT the compared result
##########################################################
compare() {
    local file_path_a="$1"
    local file_path_b="$2"

    # check whether file exist
    if [[ ! -e "${path_a}/${file_path_a}" ]] || [[ ! -e "${path_b}/${file_path_b}" ]]; then 
        usage
    fi

    # check whether 2 files are normal file
    if [[ ! -L "${path_a}/${file_path_a}" ]] && [[ ! -L "${path_b}/${file_path_b}" ]]; then
        local line_a=$(wc -l ${path_a}/${file_path_a} | awk '{print $1}')
        local line_b=$(wc -l ${path_b}/${file_path_b} | awk '{print $1}')
        
        local differ=

        # if at least one of files are binary and they are different
        # output 100% and return
        differ="$(diff -U $(max $line_a $line_b) "${path_a}/${file_path_a}" "${path_b}/${file_path_b}")"
        if [[ "$differ" ==  "binary files ${path_a}/${file_path_a} ${path_b}/${file_path_b} differ" ]] ; then
            echo "${file_path_a}: changed 100%"
            return 0
        fi

        # if 2 files are same, don't output and return
        if [[ "$differ" ==  "" ]] ; then
            return 0
        fi

        # get a, b, c by differ -u and output result
        local a=$(($(echo "$differ" | grep -c '^-') - 1))
        local b=$(($(echo "$differ" | grep -c '^[\+]') - 1))
        local c=$(echo "$differ" | grep -c '^ ')
        echo "${file_path_a}: changed $(( $(max $a $b) * 100 / ( $(max $a $b) + c ) ))%" 
        return 0
    fi

    # check whether 2 files are symbol link file
    if [[ -L "${path_a}/${file_path_a}" ]] && [[ -L "${path_b}/${file_path_b}" ]]; then
        local link_a="$(readlink ${path_a}/${file_path_a})"
        local link_b="$(readlink ${path_b}/${file_path_b})"
        if [[ "$link_a" != "$link_b" ]]; then
            echo "${file_path_a}: changed 100%"
        fi  
        return 0
    fi

    # if their type are different, output 100% 
    echo "${file_path_a}: changed 100%"
    return 0
}


##########################################################
# Check and compare two non-directory files 
# Globals:
#   path_a
#   path_b
#   option_a
# Arguments:
#   none
# Outputs:
#   STDOUT the compared result
##########################################################
compare_no_recursive() {

    # check whether file exist
    if [[ ! -e "${path_a}" ]] || [[ ! -e "${path_b}" ]]; then 
        usage
    fi

    # check whether 2 files are normal file
    if [[ ! -L "${path_a}" ]] && [[ ! -L "${path_b}" ]]; then
        local line_a=$(wc -l ${path_a} | awk '{print $1}')
        local line_b=$(wc -l ${path_b} | awk '{print $1}')
        local differ=
        differ="$(diff -U $(max $line_a $line_b) "${path_a}" "${path_b}")"
        
        # if at least one of files are binary and they are different
        # output 100% and return 
        if [[ "$differ" ==  "binary files ${path_a} ${path_b} differ" ]] ; then
            echo "changed 100%"
            return 0
        fi

        # if 2 files are same, don't output and return  
        if [[ "$differ" ==  "" ]] ; then
            return 0
        fi

        # get a, b, c by differ -u and output result 
        local a=$(($(echo "$differ" | grep -c '^-') - 1))
        local b=$(($(echo "$differ" | grep -c '^[\+]') - 1))
        local c=$(echo "$differ" | grep -c '^ ')
        echo "changed $(( $(max $a $b) * 100 / ( $(max $a $b) + c ) ))%" 
        return 0
    fi

    # check whether 2 files are symbol link file
    if [[ -L "${path_a}" ]] && [[ -L "${path_b}" ]]; then
        local link_a="$(readlink ${path_a}/${file_path_a})"
        local link_b="$(readlink ${path_b}/${file_path_b})"
        if [[ "$link_a" != "$link_b" ]]; then
            echo "changed 100%"
        fi
        return 0
    fi

    # if their type are different, output 100% 
    echo "changed 100%"
    return 0
}


##########################################################
# Check and compare files under two directory recursively  
# Globals:
#   path_a
#   path_b
# Arguments:
#   file_path_a, one of the compared directory under path_a (omitted path_a)
#   file_path_b, one of the compared directory under path_b (omitted path_b)# Outputs:
#   STDOUT the compared result
##########################################################
compare_recursive() {
    local file_path_a="$1"
    local file_path_b="$2"
    local files_a=
    local files_b=

    # get list of valid files under their directories
    files_a="$(get_files_list "${path_a}"/"${file_path_a}" )"
    files_b="$(get_files_list "${path_b}"/"${file_path_b}" )"

    # split files_a, files_b into array 
    files_a=( $files_a )
    files_b=( $files_b )

    # use index i iterates files_a
    # use index j iterates files_b
    local i=0
    local j=0
    while (( i < ${#files_a[@]})) && (( j < ${#files_b[@]})); do
        if [[ ${files_a[i]} == ${files_b[j]} ]] && (( i < ${#files_a[@]})) && (( j < ${#files_b[@]})); then
            # if bath files are directories, push them into another recursion
            # else, compare them 
            if { [[ -d "${path_a}/${file_path_a}${files_a[i]}" ]] && \
                 [[ -d "${path_b}/${file_path_b}${files_b[j]}" ]] ; } ; then
                compare_recursive "${file_path_a}${files_a[i]}/" "${file_path_b}${files_b[j]}/"    
            else
                compare "${file_path_a}${files_a[i]}" "${file_path_b}${files_b[j]}"           
            fi
            (( i += 1 ))
            (( j += 1 ))
        fi
        while [[ ${files_a[i]} < ${files_b[j]} ]] && (( i < ${#files_a[@]})) && (( j < ${#files_b[@]})); do 
            delete "${file_path_a}${files_a[i]}"
            (( i += 1 ))    
        done
        while [[ ${files_a[i]} > ${files_b[j]} ]] && (( i < ${#files_a[@]})) && (( j < ${#files_b[@]})); do 
            create "${file_path_b}${files_b[j]}"
            (( j += 1 ))
        done
    done
    while (( j < ${#files_b[@]})); do 
        create "${file_path_b}${files_b[j]}"
        (( j += 1 ))
    done
    while (( i < ${#files_a[@]})); do 
        delete "${file_path_a}${files_a[i]}"
        (( i += 1 ))    
    done
}

# ARGS record the argument array 
# option_[] record which option are chosen
# EXP records the regex for -n 
declare -ar ARGS=( "$@" ) 
declare option_a=false
declare option_l=false
declare option_n=false
declare option_r=false
declare EXP=".*"

# process and record the options 
while getopts ":ahln:r" arg; do
    case $arg in
        a)
            option_a=true
            ;;
        h)
            usage
            ;;
        l)
            option_l=true
            ;;
        n)
            option_n=true
            EXP=${OPTARG}
            ;;
        r)
            option_r=true
            ;;
        ?)
            usage
            ;;
    esac
done

# input <PATH A> <PATH B> into path_a path_b
# echo $OPTIND
path_a="${ARGS[OPTIND - 1]}"
path_b="${ARGS[OPTIND]}"

# when no <PATH A> or <PATH B> be input, output error
if [[ $path_a == "" ]] || [[ $path_b == "" ]] ; then
    usage 
fi

# condition when have option a but don't have option r, output error 
if ${option_a}  && ! ${option_r} ; then
    usage 
fi

# condition when have option n but don't have option r, output error 
if ${option_n}  && ! ${option_r} ; then
    usage
fi

# check whether no -l but has symbol file, output error 
if ! ${option_l}; then 
    if [[ -L "${path_a}" ]] || [[ -L "${path_b}" ]]; then 
        usage
    fi
fi

# check whether no -a but PATH A, B has hidden file, output error 
if ! ${option_l}; then 
    if [[ "${path_a}" =~ ^\..* ]] || [[ "${path_b}" =~ ^\..* ]]; then 
        usage
    fi
fi

# process the path_a path_b so that the '/' on the end of the path will be deleted
path_a=$(echo "$path_a" | sed 's/\/$//g')
path_b=$(echo "$path_b" | sed 's/\/$//g')


if ${option_r} ; then

    # check both of path are directories
    if { [[ -d $path_a ]] && [[ -d $path_b ]] ; } ; then
        compare_recursive
        exit 0 
    fi 
    usage
fi

if ! ${option_r} ; then

    # check both of path are not directories
    if { ! [[ -d $path_a ]] && ! [[ -d $path_b ]] ; } ; then
        compare_no_recursive    
        exit 0
    fi 
    usage
fi